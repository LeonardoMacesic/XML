<!DOCTYPE html>
<html lang="hr">
<head>
  <meta charset="UTF-8">
  <title>GameShop - Ponude</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    form.filter-form {
      margin-bottom: 2rem;
      background: #fff;
      padding: 1rem;
      border-radius: 10px;
    }
    form.filter-form label {
      margin-right: 10px;
      font-weight: bold;
    }
    form.filter-form select,
    form.filter-form input[type="text"] {
      padding: 5px;
      margin-right: 10px;
    }
  </style>
</head>
<body>

  <?php include "includes/navbar.php"; ?>

  <div class="container">
    <h1>Posebne ponude</h1>

    <form method="get" class="filter-form">
      <label for="kategorija">Kategorija:</label>
      <select name="kategorija" id="kategorija">
        <option value="">Sve</option>
        <option value="akcija">Akcija</option>
        <option value="rpg">RPG</option>
        <option value="avantura">Avantura</option>
      </select>

      <label for="sortiraj">Sortiraj po:</label>
      <select name="sortiraj" id="sortiraj">
        <option value="">--</option>
        <option value="cijena_asc">Cijena rastuće</option>
        <option value="cijena_desc">Cijena padajuće</option>
        <option value="popust">Najveći popust</option>
      </select>

      <label for="pretraga">Pretraži:</label>
      <input type="text" name="pretraga" id="pretraga" placeholder="Unesi naziv igre...">

      <button type="submit">Primijeni</button>
    </form>
    
    <?php
      $xml = simplexml_load_file("xml/ponude.xml");
      $igre = [];

      if ($xml !== false) {
        foreach ($xml->igra as $igra) {
          $igre[] = $igra;
        }
        
        
        if (!empty($_GET['kategorija'])) {
          $igre = array_filter($igre, function($igra) {
            return (string)$igra->kategorija === $_GET['kategorija'];
          });
        }

        
        if (!empty($_GET['pretraga'])) {
          $search = strtolower($_GET['pretraga']);
          $igre = array_filter($igre, function($igra) use ($search) {
            return strpos(strtolower((string)$igra->naziv), $search) !== false;
          });
        }

        
        if (!empty($_GET['sortiraj'])) {
          usort($igre, function($a, $b) {
            $sa = $_GET['sortiraj'];
            $ca = (float)$a->cijena;
            $cb = (float)$b->cijena;
            $pa = (float)$a->stara_cijena - $ca;
            $pb = (float)$b->stara_cijena - $cb;
            if ($sa === "cijena_asc") return $ca <=> $cb;
            if ($sa === "cijena_desc") return $cb <=> $ca;
            if ($sa === "popust") return $pb <=> $pa;
            return 0;
          });
        }

        
        foreach ($igre as $igra) {
          echo '<div class="game-card">';
          echo '<img src="' . htmlspecialchars($igra->slika) . '" alt="' . htmlspecialchars($igra->naziv) . '">';
          echo '<div>';
          echo '<h2>' . htmlspecialchars($igra->naziv) . '</h2>';
          echo '<p><strong>Kategorija:</strong> ' . htmlspecialchars($igra->kategorija) . '</p>';
          echo '<p><span class="price">' . htmlspecialchars($igra->cijena) . '€</span> <span class="old-price">' . htmlspecialchars($igra->stara_cijena) . '€</span></p>';
          echo '</div>';
          echo '<button class="gumb">Dodaj u košaricu</button>';
          echo '</div>';
        }
      } else {
        echo "<p>Greška pri učitavanju XML datoteke.</p>";
      }
    ?>
    
  </div>

  <footer style="margin-top: 2rem; padding: 1rem; background: #f0f0f0; text-align: center; font-size: 0.9rem;">
    <p>Leonardo Maćešić &bullet; Email: <a href="mailto:lmacesic@tvz.hr">lmacesic@tvz.hr</a></p>
  </footer>
</body>
</html>
