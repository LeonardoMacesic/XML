<nav>
  <a href="index.php">Početna</a>
  <a href="ponude.php">Ponude</a>
  <a href="kontakt.php">Kontakt</a>
</nav>
