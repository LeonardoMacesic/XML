<!DOCTYPE html>
<html lang="hr">
<head>
  <meta charset="UTF-8">
  <title>GameShop - Početna</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <?php include "includes/navbar.php"; ?>

  <div class="container">
    <h1>Dobrodošli u GameShop!</h1>
    <p>
      🎮 <strong>GameShop</strong> je tvoja digitalna destinacija za nevjerojatne ponude na najnovijim i najtraženijim video igrama!  
      Bez obzira jesi li strastveni PC igrač, obožavatelj konzola ili povremeni avanturist – imamo nešto za svakog igrača.
    </p>
    <p>
      Naša kolekcija uključuje sve, od epskih RPG naslova i napetih pucačina do obiteljskih avantura i nezavisnih hitova koji osvajaju svijet.  
      Svaki tjedan donosimo svježe ponude, ogromne popuste i ekskluzivne akcije koje ne smiješ propustiti!
    </p>
    <p>
      ✅ Originalni aktivacijski ključevi  <br>
      ✅ Trenutna isporuka e-mailom  <br>
      ✅ Sigurno plaćanje i korisnička podrška  <br>
      ✅ Do 80% popusta na top igre!
    </p>
    <p>
      GameShop nije samo trgovina – to je zajednica igrača koji cijene kvalitetu, cijenu i brzinu.  
      Klikni na <a href="ponude.php"><strong>Ponude</strong></a> i otkrij igre koje će te uvući u svjetove prepune uzbuđenja.<br>
    </p>
    <p>
      Pridruži se tisućama zadovoljnih korisnika i neka tvoja sljedeća gaming avantura započne upravo ovdje!
    </p>

    <section id="najave">
  <h2>Najave video igara koje uskoro izlaze</h2>

  <div class="najava">
    <img src="slike/dying.jpg" alt="Dying Light: The Beast" />
    <div class="najava-opis">
      <h3>Dying Light: The Beast</h3>
      <p>Pripremite se za još mračniju i intenzivniju avanturu u svijetu Dying Light s novim režimom 'The Beast'. Igra donosi potpuno nove mehanike, neprijatelje i napetu atmosferu prepunu opasnosti. Izlazak je planiran za kraj godine, a obećava sate adrenalinske akcije i preživljavanja.</p>
    </div>
  </div>

  <div class="najava">
    <img src="slike/gta.jpg" alt="GTA 6" />
    <div class="najava-opis">
      <h3>GTA 6</h3>
      <p>Očekuje se povratak serijala s još većim i detaljnijim svijetom, inovativnim gameplayom i naprednim AI sustavima. Grand Theft Auto 6 donosi novu generaciju otvorenog svijeta, s dinamičnim pričama i interaktivnim likovima. Datum izlaska još nije službeno potvrđen.</p>
    </div>
  </div>

  <div class="najava">
    <img src="slike/hollow.jpg" alt="Hollow Knight Silksong" />
    <div class="najava-opis">
      <h3>Hollow Knight Silksong</h3>
      <p>Nastavak omiljene metroidvanije donosi novu protagonistkinju Hornet, nove neprijatelje i bogat svijet za istraživanje. Silksong će testirati vaše vještine u zahtjevnim borbama i zadatcima. Igra je na putu da postane klasik žanra.</p>
    </div>
  </div>
</section>

</div>
  </div>

  <footer style="margin-top: 2rem; padding: 1rem; background: #f0f0f0; text-align: center; font-size: 0.9rem;">
    <p>Leonardo Maćešić &bullet; Email: <a href="mailto:lmacesic@tvz.hr">lmacesic@tvz.hr</a></p>
  </footer>
</body>
</html>
