<!DOCTYPE html>
<html lang="hr">
<head>
  <meta charset="UTF-8">
  <title>GameShop - Kontakt</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

  <?php include "includes/navbar.php"; ?>

  <div class="container">
    <h1>Kako do nas</h1>
  <p>Naša lokacija nalazi se u Kampusu Borongaj, Zagrebačka cesta 100, Zagreb.</p>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3127.774563288912!2d16.040457697878846!3d45.808932592826615!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4766790020667469%3A0xa9a20d6e234405b1!2sTehni%C4%8Dko%20veleu%C4%8Dili%C5%A1te%20u%20Zagrebu%20(TVZ)%20-%20INRO!5e0!3m2!1shr!2shr!4v1749379101095!5m2!1shr!2shr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    <br><br>
    <h1>Kontakt</h1>
    <p>Imate pitanja ili prijedloge? Slobodno nas kontaktirajte putem e-maila ili obrasca u nastavku.</p>
    <p><strong>Email:</strong> <a href="mailto:lmacesic@tvz.hr">lmacesic@tvz.hr</a></p>
    <form method="post" action="#">
      <label for="ime">Ime:</label><br>
      <input type="text" id="ime" name="ime"><br><br>
      <label for="email">Email:</label><br>
      <input type="email" id="email" name="email"><br><br>
      <label for="poruka">Poruka:</label><br>
      <textarea id="poruka" name="poruka" rows="5" cols="40"></textarea><br><br>
      <button type="submit">Pošalji</button>
    </form>
  </div>

  <footer style="margin-top: 2rem; padding: 1rem; background: #f0f0f0; text-align: center; font-size: 0.9rem;">
    <p>Leonardo Maćešić &bullet; Email: <a href="mailto:lmacesic@tvz.hr">lmacesic@tvz.hr</a></p>
  </footer>
</body>
</html>
